﻿using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using $ext_safeprojectname$.ApplicationServices.UseCases.Login;

namespace $safeprojectname$.Controllers
{
    [ApplicationServices.Aop.Log]
    [ApiController]
    [ApiVersion("1.0")]
    [Route("[controller]/[action]")]
    public class LoginController : ControllerBase
    {
        readonly LoginUseCase _useCase;

        public LoginController(LoginUseCase useCase)
        {
            this._useCase = useCase;
        }

        [HttpPost]
        public LoginResultDto GetDialogMode()
        {
            throw new NotImplementedException();
        }

        [HttpPost]
        public LoginResultDto SetUserPassword()
        {
            throw new NotImplementedException();
        }

        [AllowAnonymous]
        [HttpPost]
        public LoginResultDto Login(LoginRequestDto requestDto)
        {
            return this._useCase.Login(requestDto);
        }

        [HttpPost]
        public LoginResultDto Logout(LoginRequestDto _)
        {
            return this._useCase.Logout();
        }
    }
}
