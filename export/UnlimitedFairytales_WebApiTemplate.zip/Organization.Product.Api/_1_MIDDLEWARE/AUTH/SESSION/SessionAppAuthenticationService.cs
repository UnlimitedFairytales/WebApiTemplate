﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using $ext_safeprojectname$.Domain.Authentications.Repositories;
using $ext_safeprojectname$.Domain.Authentications.Services;
using $ext_safeprojectname$.Domain.Authentications.ValueObjects;
using System.Security.Claims;

namespace $safeprojectname$._1_Middleware.Auth.Session
{
    public class SessionAppAuthenticationService : IAppAuthenticationService
    {
        public static readonly string SESSION_TOKEN = "SessionToken";

        readonly IHttpContextAccessor _httpContextAccessor;
        readonly IAppAuthenticatedUserRepository _appAuthenticatedUserRepository;

        public SessionAppAuthenticationService(IHttpContextAccessor httpContextAccessor, IAppAuthenticatedUserRepository appAuthenticatedUserRepository)
        {
            this._httpContextAccessor = httpContextAccessor;
            this._appAuthenticatedUserRepository = appAuthenticatedUserRepository;
        }

        public async Task <AppAuthenticationResult> AuthenticateAsync(string userCd, string? password)
        {
            var user = this._appAuthenticatedUserRepository.FindBy(userCd, password!);
            var sessionToken = Guid.NewGuid().ToString("N");
            var claims = new List<Claim>
            {
                new(ClaimTypes.NameIdentifier, user.UserCd ?? ""),
                new(ClaimTypes.Name, user.UserName ?? ""),
                new(ClaimTypes.Email, user.Email ?? ""),
                new(ClaimTypes.Version, (user.Ver ?? 0).ToString()),
                new(SESSION_TOKEN, sessionToken)
            };
            var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var claimPrincipal = new ClaimsPrincipal(claimsIdentity);
            var authProperties = new AuthenticationProperties()
            {
                AllowRefresh = true
            };
            await this._httpContextAccessor.HttpContext!.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                claimPrincipal,
                authProperties);
            this._httpContextAccessor.HttpContext!.Session.SetString(SESSION_TOKEN, sessionToken);
            this._httpContextAccessor.HttpContext!.User = claimPrincipal;
            return new AppAuthenticationResult();
        }

        public async Task SignOutAsync()
        {
            this._httpContextAccessor.HttpContext!.Session.Clear();
            await Task.Delay(0);
        }
    }
}
