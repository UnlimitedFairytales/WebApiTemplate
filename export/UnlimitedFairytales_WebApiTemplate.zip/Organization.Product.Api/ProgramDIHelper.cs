﻿using $safeprojectname$.Middleware.Auth.Cookie;
using $safeprojectname$.Middleware.Auth.Jwt;
using $safeprojectname$.Middleware.Auth.Session;
using $ext_safeprojectname$.ApplicationServices.UseCases._Sample;
using $ext_safeprojectname$.ApplicationServices.UseCases.Login;
using $ext_safeprojectname$.Domain.Authentications.Services;
using $ext_safeprojectname$.Domain.Common.Configurations;

namespace $safeprojectname$
{
    public static class ProgramDIHelper
    {
        public static void AddApplicationServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddTransient<LoginUseCase>();
            var authOption = new AuthOptions(configuration);
            switch (authOption.AuthType)
            {
                case AuthOptions.AuthType_IdPasswordCookie:
                    services.AddTransient<IAppAuthenticationService, CookieAppAuthenticationService>();
                    break;
                case AuthOptions.AuthType_IdPasswordJwt:
                    services.AddTransient<IAppAuthenticationService, JwtAppAuthenticationService>();
                    break;
                case AuthOptions.AuthType_IdPasswordSession:
                    services.AddTransient<IAppAuthenticationService, SessionAppAuthenticationService>();
                    break;
                default:
                    break;
            }

            // Options
            services.AddTransient<AuthOptions>();

            // _Sample
            services.AddTransient<WeatherForecastUseCase>();
        }
    }
}
