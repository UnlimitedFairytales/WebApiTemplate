﻿using $safeprojectname$._1_Middleware.Auth.Cookie;
using $safeprojectname$._1_Middleware.Auth.Jwt;
using $safeprojectname$._1_Middleware.Auth.Session;
using $ext_safeprojectname$.ApplicationServices.UseCases._Sample;
using $ext_safeprojectname$.ApplicationServices.UseCases.Login;
using $ext_safeprojectname$.Domain.Authentications.Repositories;
using $ext_safeprojectname$.Domain.Authentications.Services;
using $ext_safeprojectname$.Gateways.Authentications;
using $ext_safeprojectname$.Shared.Configurations;
using $ext_safeprojectname$.Shared.Utils;
using $ext_safeprojectname$.Shared.Utils.Hasher;

namespace $safeprojectname$
{
    public static class ProgramDIHelper
    {
        public static void AddApplicationServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddTransient<CommonParams>();
            services.AddTransient<LoginUseCase>();
            var authOption = new AuthOptions(configuration);
            switch (authOption.AuthType)
            {
                case AuthOptions.AuthType_IdPasswordCookie:
                    services.AddTransient<IAppAuthenticationService, CookieAppAuthenticationService>();
                    break;
                case AuthOptions.AuthType_IdPasswordJwt:
                    services.AddTransient<IAppAuthenticationService, JwtAppAuthenticationService>();
                    break;
                case AuthOptions.AuthType_IdPasswordSession:
                    services.AddTransient<IAppAuthenticationService, SessionAppAuthenticationService>();
                    break;
                default:
                    break;
            }
            services.AddTransient<IHasher, Pbkdf2Hasher>();
            services.AddTransient<IAppAuthenticatedUserRepository, Dummy_AppAuthenticatedUserRepository>();

            // Options
            services.AddTransient<AuthOptions>();
            services.AddTransient<AntiCsrfOption>();

            // _Sample
            services.AddTransient<WeatherForecastUseCase>();
        }
    }
}
