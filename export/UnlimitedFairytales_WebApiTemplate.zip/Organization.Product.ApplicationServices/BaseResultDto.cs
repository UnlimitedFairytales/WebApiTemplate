﻿using $ext_safeprojectname$.Domain.Common.ValueObjects;

namespace $safeprojectname$
{
    public class BaseResultDto
    {
        public AppMessage? Error { get; set; }
    }
}
