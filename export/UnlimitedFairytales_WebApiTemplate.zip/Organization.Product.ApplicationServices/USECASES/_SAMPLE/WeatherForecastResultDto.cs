﻿using $ext_safeprojectname$.Domain._Sample.Entities;

namespace $safeprojectname$.UseCases._Sample
{
    public class WeatherForecastResultDto : BaseResultDto
    {
        public IEnumerable<WeatherForecast>? WeatherForecasts { get; set; }
        public string? NullPropertySample { get; set; }
        public readonly int ReadonlyField = 1;
        public int ReadonlyProperty { get; } = 1;
    }
}
