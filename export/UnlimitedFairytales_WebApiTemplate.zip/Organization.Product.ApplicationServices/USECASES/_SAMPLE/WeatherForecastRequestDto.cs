﻿namespace $safeprojectname$.UseCases._Sample
{
    public class WeatherForecastRequestDto
    {
        public bool P1_Bool { get; set; }
        public int P2_Int { get; set; }
        public string? P3_String { get; set; }
        public double P4_Double { get; set; }
    }
}
