﻿namespace $safeprojectname$.UseCases.Login
{
    public class LoginRequestDto
    {
        public string? UserCd { get; set; }
        public string? Password { get; set; }
    }
}
