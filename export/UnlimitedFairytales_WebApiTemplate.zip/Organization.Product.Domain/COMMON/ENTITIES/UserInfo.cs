﻿namespace $safeprojectname$.Common.Entities
{
    public class UserInfo
    {
        public string? UserCd { get; set; }
        public string? UserName { get; set; }
        public string? Email { get; set; }
    }
}
