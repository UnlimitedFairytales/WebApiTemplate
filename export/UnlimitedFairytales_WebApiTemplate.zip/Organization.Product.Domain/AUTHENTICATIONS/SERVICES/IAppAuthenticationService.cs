﻿using $safeprojectname$.Authentications.ValueObjects;

namespace $safeprojectname$.Authentications.Services
{
    public interface IAppAuthenticationService
    {
        Task<AppAuthenticationResult> AuthenticateAsync(string userCd, string? password);
        Task SignOutAsync();
    }
}
