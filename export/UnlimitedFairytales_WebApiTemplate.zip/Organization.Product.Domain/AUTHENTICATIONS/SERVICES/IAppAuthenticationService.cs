﻿using $safeprojectname$.Authentications.ValueObjects;

namespace $safeprojectname$.Authentications.Services
{
    public interface IAppAuthenticationService
    {
        AppAuthenticationResult Authenticate(string userCd, string? password);
        void SignOut();
    }
}
