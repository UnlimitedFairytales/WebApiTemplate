﻿namespace $safeprojectname$.Authentications.ValueObjects
{
    public class AppAuthenticationResult
    {
        public string? Token { get; set; }
    }
}
