﻿using $safeprojectname$.Authentications.Entities;

namespace $safeprojectname$.Authentications.Repositories
{
    public interface IAppAuthenticatedUserRepository
    {
        public AppAuthenticatedUser FindBy(string userCd, string password);
    }
}
